-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 14, 2023 at 08:35 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chabeebus`
--

-- --------------------------------------------------------

--
-- Table structure for table `bus`
--

CREATE TABLE `bus` (
  `bus_number` int(11) NOT NULL,
  `capacity` int(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `driveName` varchar(255) DEFAULT NULL,
  `conductorName` varchar(255) DEFAULT NULL,
  `busImage` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bus`
--

INSERT INTO `bus` (`bus_number`, `capacity`, `location`, `driveName`, `conductorName`, `busImage`) VALUES
(1, 55, 'Mati', 'Roland', 'Florabel', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(2, 65, 'Mati', 'Florabel', 'Marie Joy', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(3, 50, 'Mati', 'Francis', 'Ford', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(4, 60, 'Lupon', 'Nilo', 'Noli', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(5, 65, 'Lupon', 'Noel', 'Toto', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(6, 55, 'Lupon', 'Rolando', 'Bobot', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(7, 50, 'Butuan', 'Henry', 'Dave', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(8, 60, 'Butuan', 'David', 'James', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(9, 70, 'Butuan', 'Abraham', 'Paul', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `reservation_id` int(11) NOT NULL,
  `passenger_name` varchar(255) DEFAULT NULL,
  `dates` date DEFAULT NULL,
  `sched_id` int(11) DEFAULT NULL,
  `dept_time` time DEFAULT NULL,
  `arrival_time` time DEFAULT NULL,
  `bus_number` int(11) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `seat_number` int(255) DEFAULT NULL,
  `paid` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`reservation_id`, `passenger_name`, `dates`, `sched_id`, `dept_time`, `arrival_time`, `bus_number`, `location`, `price`, `seat_number`, `paid`) VALUES
(1, 'Eunice', '2023-05-24', 1, '11:00:00', '17:00:00', 2, 'Mati', '250.00', 1, 1),
(2, 'Lois', '2023-05-10', 2, '08:00:00', '14:00:00', 1, 'Mati', '250.00', 2, 1),
(3, 'Flor', '2023-05-10', 1, '08:00:00', '14:00:00', 7, 'Butuan', '250.00', 3, 1),
(4, 'Anna', '2023-05-10', 1, '11:00:00', '17:00:00', 1, 'Mati', '350.00', 2, 1),
(5, 'Lisa', '2023-08-24', 4, '10:00:00', '16:00:00', 4, 'Lupon', '250.00', 5, 1),
(6, 'Liza', '2023-08-02', 4, '10:00:00', '16:00:00', 4, 'LUPON', '250.00', 6, 1),
(7, NULL, '2023-08-01', 9, '14:30:00', '17:30:00', 9, 'Butuan', '400.00', 10, 1),
(8, NULL, '2023-08-01', 9, '14:30:00', '17:30:00', 9, 'Butuan', '400.00', 10, 1),
(9, NULL, '2023-08-01', 9, '14:30:00', '17:30:00', 9, 'Butuan', '400.00', 4, 1),
(10, NULL, '2023-08-01', 9, '14:30:00', '17:30:00', 9, 'Butuan', '400.00', 5, 1),
(11, NULL, '2023-08-01', 9, '14:30:00', '17:30:00', 9, 'Butuan', '400.00', 6, 1),
(12, NULL, '2023-08-01', 9, '14:30:00', '17:30:00', 9, 'Butuan', '400.00', 6, 1),
(13, NULL, '2023-08-01', 9, '14:30:00', '17:30:00', 9, 'Butuan', '400.00', 6, 1),
(14, NULL, '2023-05-24', 2, '08:00:00', '14:00:00', 2, 'Mati', '350.00', 7, 1),
(15, NULL, '2023-05-24', 2, '08:00:00', '14:00:00', 2, 'Mati', '350.00', 7, 1),
(16, NULL, '2023-05-24', 2, '08:00:00', '14:00:00', 2, 'Mati', '350.00', 7, 1),
(17, NULL, '2023-05-24', 2, '08:00:00', '14:00:00', 2, 'Mati', '350.00', 7, 1),
(18, NULL, '2023-05-03', 5, '08:00:00', '13:00:00', 5, 'Lupon', '250.00', 9, 1),
(19, NULL, '2023-05-03', 5, '08:00:00', '13:00:00', 5, 'Lupon', '250.00', 9, 1),
(20, NULL, '2023-05-03', 5, '08:00:00', '13:00:00', 5, 'Lupon', '250.00', 9, 1),
(21, NULL, '2023-05-13', 4, '10:00:00', '16:00:00', 4, 'LUPON', '250.00', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `sched_id` int(11) NOT NULL,
  `dept_time` time DEFAULT NULL,
  `arrival_time` time DEFAULT NULL,
  `bus_number` int(11) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `routes` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`sched_id`, `dept_time`, `arrival_time`, `bus_number`, `price`, `routes`) VALUES
(1, '11:00:00', '17:00:00', 1, '350.00', 'Davao-Mati'),
(2, '08:00:00', '14:00:00', 2, '350.00', 'Lupon-Mati'),
(3, '09:00:00', '15:00:00', 3, '350.00', 'Davao-Mati'),
(4, '10:00:00', '16:00:00', 4, '250.00', 'Davao-Lupon'),
(5, '08:00:00', '13:00:00', 5, '250.00', 'Butuan-Lupon'),
(6, '09:00:00', '14:00:00', 6, '250.00', 'Mati-Lupon'),
(7, '13:00:00', '16:00:00', 7, '400.00', 'Davao-Butuan'),
(8, '12:00:00', '17:00:00', 8, '400.00', 'Mati-Butuan'),
(9, '14:30:00', '17:30:00', 9, '400.00', 'Lupon-Butuan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bus`
--
ALTER TABLE `bus`
  ADD PRIMARY KEY (`bus_number`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`reservation_id`),
  ADD KEY `sched_id` (`sched_id`),
  ADD KEY `bus_number` (`bus_number`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`sched_id`),
  ADD KEY `fk_bus` (`bus_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bus`
--
ALTER TABLE `bus`
  MODIFY `bus_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `reservation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `sched_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`sched_id`) REFERENCES `schedules` (`sched_id`),
  ADD CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`bus_number`) REFERENCES `bus` (`bus_number`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `fk_bus` FOREIGN KEY (`bus_number`) REFERENCES `bus` (`bus_number`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
