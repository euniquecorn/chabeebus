-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 15, 2023 at 03:30 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chabeebus`
--
CREATE DATABASE IF NOT EXISTS `chabeebus` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `chabeebus`;

-- --------------------------------------------------------

--
-- Table structure for table `buses`
--

DROP TABLE IF EXISTS `buses`;
CREATE TABLE IF NOT EXISTS `buses` (
  `bus_number` int NOT NULL AUTO_INCREMENT,
  `capacity` int DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `driveName` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `conductorName` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `busImage` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`bus_number`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buses`
--

INSERT INTO `buses` (`bus_number`, `capacity`, `location`, `driveName`, `conductorName`, `busImage`) VALUES
(1, 55, 'Mati', 'Roland', 'Florabel', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(2, 65, 'Mati', 'Florabel', 'Marie Joy', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(3, 50, 'Mati', 'Francis', 'Ford', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(4, 60, 'Lupon', 'Nilo', 'Noli', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(5, 65, 'Lupon', 'Noel', 'Toto', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(6, 55, 'Lupon', 'Rolando', 'Bobot', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(7, 50, 'Butuan', 'Henry', 'Dave', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(8, 60, 'Butuan', 'David', 'James', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg'),
(9, 70, 'Butuan', 'Abraham', 'Paul', 'https://img.12go.co/0/plain/s3://12go-web-static/static/images/operator/6574/class/2324-outside.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

DROP TABLE IF EXISTS `reservations`;
CREATE TABLE IF NOT EXISTS `reservations` (
  `reservation_id` int NOT NULL AUTO_INCREMENT,
  `passenger_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `dates` date DEFAULT NULL,
  `sched_id` int DEFAULT NULL,
  `dept_time` time DEFAULT NULL,
  `arrival_time` time DEFAULT NULL,
  `bus_number` int DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `seat_number` int DEFAULT NULL,
  `paid` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`reservation_id`),
  KEY `sched_id` (`sched_id`),
  KEY `bus_number` (`bus_number`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`reservation_id`, `passenger_name`, `dates`, `sched_id`, `dept_time`, `arrival_time`, `bus_number`, `location`, `price`, `seat_number`, `paid`) VALUES
(1, 'Eunice', '2023-05-24', 1, '11:00:00', '17:00:00', 2, 'Mati', '250.00', 1, 1),
(2, 'Lois', '2023-05-10', 2, '08:00:00', '14:00:00', 1, 'Mati', '250.00', 2, 1),
(3, 'Flor', '2023-05-10', 1, '08:00:00', '14:00:00', 7, 'Butuan', '250.00', 3, 1),
(5, 'Lisa', '2023-08-24', 4, '10:00:00', '16:00:00', 4, 'Lupon', '250.00', 5, 1),
(6, 'Liza', '2023-08-02', 4, '10:00:00', '16:00:00', 4, 'LUPON', '250.00', 6, 1),
(7, NULL, '2023-08-01', 9, '14:30:00', '17:30:00', 9, 'Butuan', '400.00', 10, 1),
(9, NULL, '2023-08-01', 9, '14:30:00', '17:30:00', 9, 'Butuan', '400.00', 4, 1),
(10, NULL, '2023-08-01', 9, '14:30:00', '17:30:00', 9, 'Butuan', '400.00', 5, 1),
(18, NULL, '2023-05-03', 5, '08:00:00', '13:00:00', 5, 'Lupon', '250.00', 9, 1),
(19, NULL, '2023-05-03', 5, '08:00:00', '13:00:00', 5, 'Lupon', '250.00', 9, 1),
(20, NULL, '2023-05-03', 5, '08:00:00', '13:00:00', 5, 'Lupon', '250.00', 9, 1),
(21, NULL, '2023-05-13', 4, '10:00:00', '16:00:00', 4, 'LUPON', '250.00', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

DROP TABLE IF EXISTS `schedules`;
CREATE TABLE IF NOT EXISTS `schedules` (
  `sched_id` int NOT NULL AUTO_INCREMENT,
  `dept_time` time DEFAULT NULL,
  `arrival_time` time DEFAULT NULL,
  `bus_number` int DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `routes` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`sched_id`),
  KEY `fk_bus` (`bus_number`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`sched_id`, `dept_time`, `arrival_time`, `bus_number`, `price`, `routes`) VALUES
(1, '11:00:00', '17:00:00', 1, '350.00', 'Davao-Mati'),
(2, '08:00:00', '14:00:00', 2, '350.00', 'Lupon-Mati'),
(3, '09:00:00', '15:00:00', 3, '350.00', 'Davao-Mati'),
(4, '10:00:00', '16:00:00', 4, '250.00', 'Davao-Lupon'),
(5, '08:00:00', '13:00:00', 5, '250.00', 'Butuan-Lupon'),
(6, '09:00:00', '14:00:00', 6, '250.00', 'Mati-Lupon'),
(7, '13:00:00', '16:00:00', 7, '400.00', 'Davao-Butuan'),
(8, '12:00:00', '17:00:00', 8, '400.00', 'Mati-Butuan'),
(9, '14:30:00', '17:30:00', 9, '400.00', 'Lupon-Butuan');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`sched_id`) REFERENCES `schedules` (`sched_id`),
  ADD CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`bus_number`) REFERENCES `buses` (`bus_number`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `fk_bus` FOREIGN KEY (`bus_number`) REFERENCES `buses` (`bus_number`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
